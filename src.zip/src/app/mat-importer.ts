import { NgModule } from '@angular/core'
import {MatButtonModule, MatCheckboxModule,MatToolbarModule,
MatGridListModule,MatCardModule} from '@angular/material';

@NgModule({
  imports: [MatButtonModule, MatCheckboxModule,MatToolbarModule,MatGridListModule,MatCardModule],
  exports: [MatButtonModule, MatCheckboxModule,MatToolbarModule,MatGridListModule,MatCardModule],
})
export class MatImporter {
}
