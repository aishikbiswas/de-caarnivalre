import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-macro-email',
  templateUrl: './macro-email.component.html',
  styleUrls: ['./macro-email.component.css']
})
export class MacroEmailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
