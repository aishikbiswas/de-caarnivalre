import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MacroEmailComponent } from './macro-email.component';

describe('MacroEmailComponent', () => {
  let component: MacroEmailComponent;
  let fixture: ComponentFixture<MacroEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MacroEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MacroEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
