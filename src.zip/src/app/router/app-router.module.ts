import { NgModule }              from '@angular/core';
import { RouterModule, Routes }  from '@angular/router';
import { HomeComponent} from '../home/home.component';
import { MacroEmailComponent } from '../macro-email/macro-email.component';
import { ErrorComponent } from '../error/error.component';

const appRoutes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'macroEmail',        component: MacroEmailComponent },
    { path: '',   redirectTo: '/home', pathMatch: 'full' },
    { path: '**', component: ErrorComponent }
  ];
   
  @NgModule({
    imports: [
      RouterModule.forRoot(
        appRoutes,
        { enableTracing: true } // <-- debugging purposes only
      )
    ],
    exports: [
      RouterModule
    ]
  })

export class Router {
}