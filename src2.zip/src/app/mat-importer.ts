import { NgModule } from '@angular/core'
import {MatButtonModule, MatCheckboxModule,MatToolbarModule,
MatGridListModule,MatCardModule,MatStepperModule,matStepperAnimations,MatFormFieldModule,MatInputModule} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  imports: [MatButtonModule, MatCheckboxModule,MatToolbarModule,MatGridListModule,MatCardModule,BrowserAnimationsModule,MatStepperModule,MatFormFieldModule
  ,MatInputModule],
  exports: [MatButtonModule, MatCheckboxModule,MatToolbarModule,MatGridListModule,MatCardModule,BrowserAnimationsModule,MatStepperModule,MatFormFieldModule,
  MatInputModule],
})
export class MatImporter {
}
