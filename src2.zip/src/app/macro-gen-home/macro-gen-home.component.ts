import { Component, OnInit } from '@angular/core';
import { homeTransition } from "../animations/slide";

@Component({
  selector: 'app-macro-gen-home',
  templateUrl: './macro-gen-home.component.html',
  styleUrls: ['./macro-gen-home.component.css'],
  animations:[homeTransition],
  host:{
    '[@homeTransition]': ''
  }
})
export class MacroGenHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
