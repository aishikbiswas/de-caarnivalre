import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MacroGenHomeComponent } from './macro-gen-home.component';

describe('MacroGenHomeComponent', () => {
  let component: MacroGenHomeComponent;
  let fixture: ComponentFixture<MacroGenHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MacroGenHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MacroGenHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
