import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';

import { ErrorComponent } from './error/error.component';
import { Routers } from './router/app-router.module';
import { MatImporter } from './mat-importer';
import { MacroGenHomeComponent } from './macro-gen-home/macro-gen-home.component';
import { SingleMailFormComponent } from './single-mail-form/single-mail-form.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    
    ErrorComponent,
    MacroGenHomeComponent,
    SingleMailFormComponent,
    
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    
    Routers,
    MatImporter
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
