import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { homeTransition } from '../animations/slide';
@Component({
  selector: 'app-single-mail-form',
  templateUrl: './single-mail-form.component.html',
  styleUrls: ['./single-mail-form.component.css'],
  animations: [ homeTransition ],
  host: {
    '[@homeTransition]': ''
  }
})
export class SingleMailFormComponent implements OnInit {
  isLinear = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  constructor(private _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }
  save(){
    console.log(this.firstFormGroup.get('firstCtrl').value);
  }

}
