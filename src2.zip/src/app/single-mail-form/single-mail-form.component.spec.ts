import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleMailFormComponent } from './single-mail-form.component';

describe('SingleMailFormComponent', () => {
  let component: SingleMailFormComponent;
  let fixture: ComponentFixture<SingleMailFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingleMailFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleMailFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
