import { NgModule }              from '@angular/core';
import { RouterModule, Routes }  from '@angular/router';
import { HomeComponent} from '../home/home.component';
import { MacroGenHomeComponent } from "../macro-gen-home/macro-gen-home.component";
import { ErrorComponent } from '../error/error.component';
import { SingleMailFormComponent } from "../single-mail-form/single-mail-form.component";
const appRoutes: Routes = [
    { path: 'home', component: HomeComponent ,data: { state: 'home'}},
    { path: 'macroHome',component: MacroGenHomeComponent ,data: { state: 'macroHome'}},
    { path: 'singleMail',component: SingleMailFormComponent ,data: { state: 'singleMail'}},
    { path: '',redirectTo:'/home',pathMatch:'full' },
    { path: '**', component: ErrorComponent }
  ];
   
  @NgModule({
    imports: [
      RouterModule.forRoot(
        appRoutes,
        {  } // <-- debugging purposes only
      )
    ],
    exports: [
      RouterModule
    ]
  })

export class Routers{
}