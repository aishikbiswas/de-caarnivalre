import { Component } from '@angular/core';
import { routerTransition } from "./animations/slide";
import { RouterOutlet } from '../../node_modules/@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations:[routerTransition]
})
export class AppComponent {
  getState(outlet){
   // console.log(outletRef);
  
    return outlet.activatedRouteData.state;
  }
}
