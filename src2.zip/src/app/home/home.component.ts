import { Component, OnInit } from '@angular/core';
import { homeTransition } from "../animations/slide";



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  animations: [ homeTransition ],
  host: {
    '[@homeTransition]': ''
  }
})
export class HomeComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
    
  }

}
