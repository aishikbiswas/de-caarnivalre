exports.uploadExcel3 = function(req, res)
{	var newPath = __dirname +"/../../uploads/temp.xlsx" ;
	var form = new formidable.IncomingForm();
	 console.log("hello");
	form.parse(req, function(err, fields, files) {
					const stream2n = new Writable();
					stream2n.result = [];
					stream2n._write = function (chunk, enc, next) {
						this.result.push(chunk);
					};
				
					var workbook = new Excel.Workbook();
					 var wrk2 = new Excel.Workbook();
					 var sheet = wrk2.addWorksheet('Details');
					var rarray = [];
					var userID = 1001;
					var empId = 5000;
					workbook.xlsx.readFile(files.file.path)
					.then(function() {
						
						var worksheet = workbook.getWorksheet(1);
						
						worksheet.eachRow({ includeEmpty: true }, function(row, rowNumber) {
						var arr = [];
						if(rowNumber == 1){
							arr.push("Group Id");
							arr.push("User ID");
							arr.push("Emp ID");
							for(i=1;i<row.values.length;i++){
								arr.push(row.values[i]);
							}
							sheet.addRow(arr);
						}else
						{		
							arr.push("Group Id");
							arr.push(userID);
							if(row.values[3] == "Employee"){
								empId++;
								arr.push(empId);
							}else{
								arr.push(empId);
							}
							
							for(i=1;i<row.values.length;i++){
								arr.push(row.values[i]);
							}
							userID++;
							sheet.addRow(arr);
						}
					})
					
					
					wrk2.xlsx.writeFile(newPath)
						.then(function() {
							
						
						res.json({'success': true});
						});
					
				
					
						
					});
                

	});
}


exports.uploadExcel4 = function(req, res)
{	
	var newPath = __dirname +"/../../uploads/temp.xlsx" ;
	res.download(newPath);
}